Cppy Release Notes
===================

1.1.0 - unreleased
------------------
- drop Python 2 support PR #3
- add documentation and tests PR #3
- add cast_py_tp_doc to cast "cleanly" to void* for use in PyType_Slot

1.0.2 - 09/28/2014
------------------
- update license header

1.0.1 - 09/28/2014
------------------
- fix Python 3 int check

1.0.0 - 09/24/2014
------------------
- first release
