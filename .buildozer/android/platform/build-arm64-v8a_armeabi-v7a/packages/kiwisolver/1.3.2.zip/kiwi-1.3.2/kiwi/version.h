/*-----------------------------------------------------------------------------
| Copyright (c) 2013-2020, Nucleic Development Team.
|
| Distributed under the terms of the Modified BSD License.
|
| The full license is in the file LICENSE, distributed with this software.
|----------------------------------------------------------------------------*/
#pragma once

#define KIWI_MAJOR_VERSION 1
#define KIWI_MINOR_VERSION 3
#define KIWI_MICRO_VERSION 1
#define KIWI_VERSION_HEX 0x010301
#define KIWI_VERSION "1.3.1"
