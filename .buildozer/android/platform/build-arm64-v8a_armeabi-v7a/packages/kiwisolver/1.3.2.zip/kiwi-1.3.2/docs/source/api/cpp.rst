Kiwisolver C++ API
==================

Under construction
